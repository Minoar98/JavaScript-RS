//print all the even numbers form 1-10 using for loop.
for (let i = 1; i <= 10; i++) {
    if(i % 2 === 0){
        console.log(i);
    }
}

//print all the even numbers form 1-10 using while loop.

let i = 1;
while(i <= 10){
    if(i % 2 ===0){
        console.log(i);
    }
    i++
}
