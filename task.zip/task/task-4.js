//print all the  numbers form 1-20 using for loop that is divisble by 3

for (let i = 1; i <= 20; i++){
    if(i % 3 === 0){
        console.log(i);
    }
}

////print all the  numbers form 1-20 using while loop that is divisble by 3
let i = 1;
while(i <= 20){
    if(i % 3 === 0){
     console.log(i);   
    }
    i++
}