//4. A function called "multiply" takes in two parameters and returns the product of the two numbers.
function multiply(num1, num2){
    return num1 * num2
}
console.log(multiply(25, 5));