// /A function called "isEven" takes in a number as a parameter and returns true if the number is even, and false if the number is odd.

function isEven(num){
    return num

}
isEven(20);