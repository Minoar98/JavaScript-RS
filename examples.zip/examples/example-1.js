// 1. A function called "maxOfTwo" takes two numbers as parameters and returns the largest of the two.

function maxOfTwo(num1, num2){
    if(num2  > num1){
        return num2
    }
}

console.log(maxOfTwo(10, 20));