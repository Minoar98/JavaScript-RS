//A function called "division" takes a parameter and returns the division by 5. (use default parameter).

function division(num = 25){
    return num / 5
}
console.log(division(30));