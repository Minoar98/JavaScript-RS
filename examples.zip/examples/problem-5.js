//5. A function called "division" takes in two parameters and returns the division of the two numbers.

function division(num1, num2){
   return num1 / num2;

}
console.log(division(125, 25));