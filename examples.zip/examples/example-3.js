//3. A function called "convertToFahrenheit" takes a temperature in Celsius as a parameter and returns the temperature in Fahrenheit.
 function convertToFahrenheit(Celsius){
    return (Celsius * 9/5) + 32
 }

 console.log(convertToFahrenheit(80));